import random
import pygame

SCREEN_HEIGHT = 500


class Pipe:
    VELOCITY = -5
    GAP = 140
    WIDTH = 52
    IMG_HEIGHT = 320

    def __init__(self, x):
        self.x = x
        self.top_height = random.randint(50, SCREEN_HEIGHT - self.GAP - 50)
        self.passed = False
        self.pipe_img = None
        self._load_images()

    def _load_images(self):
        for name in ("pipe-green.png", "pipe-red.png", "pipe.png"):
            try:
                self.pipe_img = pygame.image.load(f"assets/images/{name}").convert_alpha()
                return
            except:
                continue
        surf = pygame.Surface((self.WIDTH, self.IMG_HEIGHT))
        surf.fill((34, 139, 34))
        self.pipe_img = surf

    def recycle(self, spawn_x):
        self.x = spawn_x
        self.top_height = random.randint(50, SCREEN_HEIGHT - self.GAP - 50)
        self.passed = False

    def update(self):
        self.x += self.VELOCITY

    def draw(self, surface):
        img_h = self.pipe_img.get_height()
        top_flipped = pygame.transform.flip(self.pipe_img, False, True)
        surface.blit(top_flipped, (self.x, self.top_height - img_h))
        surface.blit(self.pipe_img, (self.x, self.top_height + self.GAP))

    def collide(self, bird):
        bird_rect = bird.get_rect()
        top_rect = pygame.Rect(self.x, 0, self.WIDTH, self.top_height)
        bottom_rect = pygame.Rect(self.x, self.top_height + self.GAP, self.WIDTH, SCREEN_HEIGHT)
        return bird_rect.colliderect(top_rect) or bird_rect.colliderect(bottom_rect)