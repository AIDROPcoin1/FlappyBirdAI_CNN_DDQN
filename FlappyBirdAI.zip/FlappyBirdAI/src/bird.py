import pygame


class Bird:
    WIDTH = 34
    HEIGHT = 24

    def __init__(self, x, y, color="yellow"):
        self.x = x
        self.y = y
        self.color = color
        self.velocity = 0.0
        self.gravity = 0.5
        self.flap_strength = -6
        self.animation_cycle = 0
        self.images = []
        self._load_images()

    def _load_images(self):
        try:
            prefix = f"{self.color}bird"
            self.images = [
                pygame.image.load(f"assets/images/{prefix}-upflap.png").convert_alpha(),
                pygame.image.load(f"assets/images/{prefix}-midflap.png").convert_alpha(),
                pygame.image.load(f"assets/images/{prefix}-downflap.png").convert_alpha(),
            ]
        except:
            surf = pygame.Surface((self.WIDTH, self.HEIGHT), pygame.SRCALPHA)
            color_map = {"yellow": (255, 220, 0), "blue": (50, 130, 255), "red": (220, 50, 50)}
            surf.fill(color_map.get(self.color, (255, 220, 0)))
            self.images = [surf, surf, surf]

    def flap(self):
        self.velocity = self.flap_strength

    def update(self):
        self.velocity += self.gravity
        self.y += int(self.velocity)
        self.animation_cycle += 1

    def draw(self, surface):
        idx = (self.animation_cycle // 5) % 3
        surface.blit(self.images[idx], (self.x, self.y))

    def get_mask(self):
        return pygame.mask.from_surface(self.images[0])

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.WIDTH, self.HEIGHT)