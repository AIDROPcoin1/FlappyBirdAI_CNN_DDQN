import torch
import numpy as np
import os
from src.dqn_net import DQN

class AIController:
    def __init__(self, model_path):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = DQN()
        
        # SỬA LỖI ĐƯỜNG DẪN: Tự động tính toán đường dẫn tuyệt đối dựa trên vị trí file ai_controller.py
        if not os.path.isabs(model_path):
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # Đi ngược lên một cấp tìm thư mục models
            base_dir = os.path.dirname(current_dir)
            model_path = os.path.join(base_dir, model_path)

        if os.path.exists(model_path):
            # Ép map_location về thiết bị phần cứng hiện tại (CPU/GPU cục bộ)
            self.model.load_state_dict(torch.load(model_path, map_location=self.device))
            print(f"🎉 [SUCCESS] Đã nạp siêu não bộ bất tử: {model_path} trên {self.device}")
        else:
            raise FileNotFoundError(f"❌ [LỖI] Không tìm thấy file checkpoint tại: {model_path}. Hiếu kiểm tra lại thư mục chứa file nhé!")

        self.model.to(self.device)
        self.model.eval()

    def get_action(self, state):
        # Đưa state vào Tensor trơn tru
        tensor = torch.FloatTensor(np.array(state)).unsqueeze(0).to(self.device)
        with torch.no_grad():
            return self.model(tensor).argmax(dim=1).item()