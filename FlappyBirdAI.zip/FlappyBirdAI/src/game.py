import pygame
import numpy as np
import math
import collections
from src.bird import Bird
from src.pipe import Pipe
from src.base import Ground

SCREEN_WIDTH  = 400
SCREEN_HEIGHT = 500
OBS_W       = 84
OBS_H       = 84
FRAMES = 4

_SX       = OBS_W  / SCREEN_WIDTH    # 0.21
_SY       = OBS_H  / SCREEN_HEIGHT   # 0.168
_GND_OY   = int((SCREEN_HEIGHT - 80) * _SY)   # 70
_BIRD_OX0 = max(0,    int(80       * _SX))     # 16
_BIRD_OX1 = min(OBS_W, int((80+34) * _SX))    # 23

SKY_COLOR    = (78,  192, 202)
PIPE_COLOR   = (0,   150,  0)
GROUND_COLOR = (200, 160, 100)
BIRD_COLOR   = (255, 220,   0)

# Pre-computed grayscale values — must match Colab FlappyEnv exactly
V_SKY    = 0.624
V_PIPE   = 0.345
V_GROUND = 0.647
V_BIRD   = 0.805

class _DummyFont:
    def render(self, text, aa, color):
        s = pygame.Surface((max(1, len(text) * 7), 18), pygame.SRCALPHA)
        s.fill((0, 0, 0, 0))
        return s
    def size(self, text):
        return (len(text) * 7, 18)

def _safe_font(path, size):
    try:
        pygame.font.init()
        f = pygame.font.Font(path, size)
        # Chạy thử nghiệm kết quả render chữ xem SDL có chịu tải không
        test = f.render("t", True, (0, 0, 0))
        if test is None:
            return _DummyFont()
        return f
    except:
        return pygame.font.SysFont(None, size)


class GameInstance:
    def __init__(self, bird_color="yellow"):
        self.bird_color  = bird_color
        self.best_score  = 0
        self.state       = "waiting"
        self.bob_timer   = 0
        self._obs_arr    = np.full((OBS_H, OBS_W), V_SKY, dtype=np.float32)
        self._frame_buf  = collections.deque(maxlen=FRAMES)
        self._load_assets()
        self.reset()

    def _load_assets(self):
        try:
            raw = pygame.image.load("assets/images/background-day.png")
            self.bg_img = pygame.transform.scale(raw, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except:
            self.bg_img = None
        try:
            self.gameover_img = pygame.image.load("assets/images/gameover.png")
        except:
            self.gameover_img = None
        try:
            self.msg_img = pygame.image.load("assets/images/message.png")
        except:
            self.msg_img = None

        pygame.font.init()
        p = "assets/fonts/flappy.ttf"
        self.font_score = _safe_font(p, 44)
        self.font_label = _safe_font(p, 20)
        self.font_best  = _safe_font(p, 16)
        self.font_hint  = _safe_font(p, 16)
        self.font_dead  = _safe_font(p, 18)

        self._load_sounds()

    def _load_sounds(self):
        self.snd_wing = self.snd_point = self.snd_hit = None
        try:
            pygame.mixer.init()
            self.snd_wing  = pygame.mixer.Sound("assets/sounds/wing.wav")
            self.snd_point = pygame.mixer.Sound("assets/sounds/point.wav")
            self.snd_hit   = pygame.mixer.Sound("assets/sounds/hit.wav")
        except:
            pass

    def _outlined(self, font, text, color, outline=(0, 0, 0), width=1):
        try:
            base = font.render(text, True, color)
            if base is None:
                return pygame.Surface((10, 10))
            
            w, h = base.get_size()
            pad  = width + 1
            surf = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
            
            for ox, oy in [(-width,-width),(0,-width),(width,-width),
                           (-width, 0),             (width, 0),
                           (-width, width),(0, width),(width, width)]:
                s = font.render(text, True, outline)
                if s is not None:
                    surf.blit(s, (pad + ox, pad + oy))
            surf.blit(base, (pad, pad))
            return surf
        except:
            # Fallback tối thượng: Trả về một surface đen rỗng nếu SDL lỗi render text
            return pygame.Surface((max(1, len(text) * 7), 18))

    def reset(self):
        self.bird   = Bird(80, SCREEN_HEIGHT // 2, self.bird_color)
        self.pipe   = Pipe(SCREEN_WIDTH + 60)
        self.ground = Ground(SCREEN_HEIGHT - 80)
        self.score  = 0
        self.bob_timer = 0
        self._frame_buf.clear()
        frame = self._capture_obs()
        for _ in range(FRAMES):
            self._frame_buf.append(frame)

    def _capture_obs(self):
        arr = self._obs_arr
        arr[:] = V_SKY
        px0 = max(0,    int(self.pipe.x             * _SX))
        px1 = min(OBS_W, int((self.pipe.x + Pipe.WIDTH) * _SX))
        if px0 < px1:
            pt = max(0,      int(self.pipe.top_height * _SY))
            pb = min(_GND_OY, int((self.pipe.top_height + Pipe.GAP) * _SY))
            if pt > 0:   arr[:pt, px0:px1] = V_PIPE
            if pb < _GND_OY: arr[pb:_GND_OY, px0:px1] = V_PIPE
        arr[_GND_OY:, :] = V_GROUND
        by0 = max(0,      int(self.bird.y * _SY))
        by1 = min(_GND_OY, int((self.bird.y + Bird.HEIGHT) * _SY))
        if by0 < by1:
            arr[by0:by1, _BIRD_OX0:_BIRD_OX1] = V_BIRD
        return arr.copy()

    def step_rl(self, action):
        prev = self.score
        if action == 1:
            self.bird.flap()
        self.update()
        if self.state == "dead":
            return self.get_state(), -1.0, True
        reward = 0.1 + (1.0 if self.score > prev else 0.0)
        return self.get_state(), reward, False

    def reset_rl(self):
        self.reset()
        self.state = "playing"
        return self.get_state()

    def get_state(self):
        return np.array(list(self._frame_buf), dtype=np.float32)

    def flap(self):
        self.bird.flap()
        if self.snd_wing:
            try: self.snd_wing.play()
            except: pass

    def update(self):
        self.ground.update()

        if self.state == "waiting":
            self.bob_timer += 1
            self.bird.y = SCREEN_HEIGHT // 2 + int(12 * math.sin(self.bob_timer * 0.06))
            self.bird.animation_cycle += 1
            self.bird.velocity = 0
            return

        if self.state == "dead":
            return

        self.bird.update()
        self.pipe.update()

        if self.pipe.x + Pipe.WIDTH < 0:
            self.pipe.recycle(SCREEN_WIDTH)

        if not self.pipe.passed and self.pipe.x + Pipe.WIDTH < self.bird.x:
            self.pipe.passed = True
            self.score += 1
            if self.score > self.best_score:
                self.best_score = self.score
            if self.snd_point:
                try: self.snd_point.play()
                except: pass

        hit_ceiling = self.bird.y <= 0
        hit_ground  = self.bird.y + Bird.HEIGHT >= SCREEN_HEIGHT - 80
        if hit_ceiling or hit_ground or self.pipe.collide(self.bird):
            self.state = "dead"
            if self.snd_hit:
                try: self.snd_hit.play()
                except: pass
            return

        self._frame_buf.append(self._capture_obs())

    def draw(self, surface, label, player_is_playing=False):
        try:
            if self.bg_img:
                surface.blit(self.bg_img, (0, 0))
            else:
                surface.fill(SKY_COLOR)

            if self.state != "waiting":
                self.pipe.draw(surface)

            self.ground.draw(surface)
            self.bird.draw(surface)

            # An toàn cho nhãn Text Model / AI
            no_model   = "NO MODEL" in label
            lbl_color  = (255, 100, 60) if no_model else (255, 230, 50)
            lbl_surf   = self._outlined(self.font_label, label, lbl_color, (0,0,0), 1)
            if lbl_surf:
                surface.blit(lbl_surf, (6, 6))

            # An toàn cho chữ hiển thị High Score
            best_surf = self._outlined(self.font_best, f"BEST  {self.best_score}", (240,240,240), (0,0,0), 1)
            if best_surf:
                surface.blit(best_surf, (SCREEN_WIDTH - best_surf.get_width() - 6, 8))

            if self.state == "playing":
                sc  = str(self.score)
                sx  = SCREEN_WIDTH // 2
                try:
                    shd = self.font_score.render(sc, True, (50, 50, 50))
                    mn  = self.font_score.render(sc, True, (255, 255, 255))
                    if shd and mn:
                        surface.blit(shd, (sx - shd.get_width() // 2 + 2, 48))
                        surface.blit(mn,  (sx - mn.get_width()  // 2,     46))
                except:
                    pass

            if self.state == "waiting":
                self._draw_waiting(surface)
            elif self.state == "dead":
                self._draw_dead(surface, label, player_is_playing)
        except Exception as e:
            # Đảm bảo hàm draw chính không bao giờ crash cell preview của Matplotlib
            pass

    def _draw_waiting(self, surface):
        if self.msg_img:
            surface.blit(self.msg_img, (SCREEN_WIDTH // 2 - self.msg_img.get_width() // 2, SCREEN_HEIGHT // 2 - 70))
        else:
            try:
                bg = pygame.Surface((270, 50))
                bg.set_alpha(160)
                bg.fill((0, 0, 0))
                surface.blit(bg, (SCREEN_WIDTH // 2 - 135, SCREEN_HEIGHT // 2 - 10))
                p = self._outlined(self.font_hint, "PRESS  SPACE  TO  START", (255,255,255), (0,0,0), 1)
                if p:
                    surface.blit(p, (SCREEN_WIDTH // 2 - p.get_width() // 2, SCREEN_HEIGHT // 2))
            except:
                pass

    def _draw_dead(self, surface, label, player_is_playing):
        try:
            ov = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            ov.set_alpha(145)
            ov.fill((0, 0, 0))
            surface.blit(ov, (0, 0))
        except:
            pass

        if self.gameover_img:
            surface.blit(self.gameover_img, (SCREEN_WIDTH // 2 - self.gameover_img.get_width() // 2, SCREEN_HEIGHT // 2 - 70))
        else:
            go = self._outlined(self.font_score, "GAME  OVER", (255,75,75), (80,0,0), 2)
            if go:
                surface.blit(go, (SCREEN_WIDTH // 2 - go.get_width() // 2, SCREEN_HEIGHT // 2 - 45))

        sc = self._outlined(self.font_dead, f"Score  {self.score}", (255,255,255), (0,0,0), 1)
        if sc:
            surface.blit(sc, (SCREEN_WIDTH // 2 - sc.get_width() // 2, SCREEN_HEIGHT // 2 + 12))

        if label == "YOU":
            h = self._outlined(self.font_hint, "SPACE  to  restart", (200,200,200), (0,0,0), 1)
        elif player_is_playing:
            h = self._outlined(self.font_hint, "resuming...", (180,230,180), (0,0,0), 1)
        else:
            h = self._outlined(self.font_hint, "R  to  restart  AI", (190,190,190), (0,0,0), 1)
        
        if h:
            surface.blit(h, (SCREEN_WIDTH // 2 - h.get_width() // 2, SCREEN_HEIGHT // 2 + 46))