import pygame

SCREEN_WIDTH = 400


class Ground:
    VELOCITY = -5

    def __init__(self, y):
        self.y = y
        self.x1 = 0
        self.x2 = SCREEN_WIDTH
        self.ground_img = None
        self._load_images()

    def _load_images(self):
        for name in ("base.png", "ground.png"):
            try:
                img = pygame.image.load(f"assets/images/{name}").convert_alpha()
                self.ground_img = pygame.transform.scale(img, (SCREEN_WIDTH, 80))
                return
            except:
                continue
        surf = pygame.Surface((SCREEN_WIDTH, 80))
        surf.fill((222, 184, 135))
        self.ground_img = surf

    def update(self):
        self.x1 += self.VELOCITY
        self.x2 += self.VELOCITY
        if self.x1 + SCREEN_WIDTH < 0:
            self.x1 = self.x2 + SCREEN_WIDTH
        if self.x2 + SCREEN_WIDTH < 0:
            self.x2 = self.x1 + SCREEN_WIDTH

    def draw(self, surface):
        surface.blit(self.ground_img, (self.x1, self.y))
        surface.blit(self.ground_img, (self.x2, self.y))