import pygame
import sys
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from src.game import GameInstance
from src.ai_controller import AIController

SCREEN_WIDTH = 400
SCREEN_HEIGHT = 500
DIVIDER_W = 2
WINDOW_W = SCREEN_WIDTH * 2 + DIVIDER_W
AI_RESPAWN_DELAY = 90


def main():
    pygame.init()
    pygame.display.set_caption("Flappy Bird — AI vs You")
    screen = pygame.display.set_mode((WINDOW_W, SCREEN_HEIGHT))
    clock = pygame.time.Clock()

    try:
        ai_ctrl = AIController("models/bird_brain.pth")
        ai_ready = True
    except Exception as e:
        print(f"Model not found: {e}")
        ai_ctrl = None
        ai_ready = False

    ai_game = GameInstance(bird_color="blue")
    pl_game = GameInstance(bird_color="yellow")

    ai_game.state = "playing"

    ai_respawn_timer = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_SPACE:
                    if pl_game.state == "waiting":
                        pl_game.state = "playing"
                        pl_game.flap()
                    elif pl_game.state == "playing":
                        pl_game.flap()
                    elif pl_game.state == "dead":
                        pl_game.reset()
                        pl_game.state = "playing"
                        pl_game.flap()
                if event.key == pygame.K_r:
                    if ai_game.state == "dead":
                        ai_game.reset()
                        ai_game.state = "playing"
                        ai_respawn_timer = 0

        if ai_game.state == "dead":
            if pl_game.state == "playing":
                ai_respawn_timer += 1
                if ai_respawn_timer >= AI_RESPAWN_DELAY:
                    ai_game.reset()
                    ai_game.state = "playing"
                    ai_respawn_timer = 0
            else:
                ai_respawn_timer = 0
        elif ai_game.state == "playing":
            if ai_ready and ai_ctrl:
                action = ai_ctrl.get_action(ai_game.get_state())
                if action == 1:
                    ai_game.flap()

        ai_game.update()
        pl_game.update()

        screen.fill((30, 30, 30))
        left_surf = screen.subsurface(pygame.Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
        right_surf = screen.subsurface(pygame.Rect(SCREEN_WIDTH + DIVIDER_W, 0, SCREEN_WIDTH, SCREEN_HEIGHT))

        player_is_playing = (pl_game.state == "playing")
        ai_label = "AI" if ai_ready else "AI  NO MODEL"
        ai_game.draw(left_surf, ai_label, player_is_playing)
        pl_game.draw(right_surf, "YOU", False)

        pygame.draw.rect(screen, (50, 50, 50), pygame.Rect(SCREEN_WIDTH, 0, DIVIDER_W, SCREEN_HEIGHT))

        pygame.display.flip()
        clock.tick(60)


if __name__ == "__main__":
    main()