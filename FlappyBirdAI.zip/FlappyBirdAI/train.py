import os, sys

if not __import__("pygame").get_init():
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    import pygame
    pygame.init()

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import collections, random, time

from src.game import GameInstance
from src.dqn_net import DQN

# =======================================================
# ĐỒNG BỘ SIÊU THAM SỐ TỐI THƯỢNG TỪ COLAB
# =======================================================
NUM_ENVS         = 32
MAX_STEPS        = 10_000_000
GAMMA            = 0.99
LR               = 1e-4
BATCH_SIZE       = 32
BUFFER_SIZE      = 100_000  # Nâng cấp lên bộ đệm 10 vạn mẫu thử
LEARN_START      = 10_000   # Chờ nạp đủ 10k mẫu mới học bám sát Colab
EPS_START        = 1.0
EPS_END          = 0.01
EPS_DECAY        = 250_000  # Kéo dài thời gian khám phá
TARGET_UPDATE    = 1_000    # Cập nhật mạng đích dày hơn cho Double DQN
CHECKPOINT_EVERY = 300_000
LOG_EVERY        = 30_000
TIME_LIMIT_SEC   = 36000    # Kéo dài giới hạn thời gian chạy
RESUME_FROM      = ""
MODEL_PATH       = "models/bird_brain.pth"
# =======================================================

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class ReplayBuffer:
    def __init__(self, cap):
        self.cap = cap; self.pos = 0; self.size = 0
        self.s  = np.zeros((cap, 4, 84, 84), dtype=np.uint8)
        self.ns = np.zeros((cap, 4, 84, 84), dtype=np.uint8)
        self.a  = np.zeros(cap, dtype=np.int64)
        self.r  = np.zeros(cap, dtype=np.float32)
        self.d  = np.zeros(cap, dtype=np.float32)

    def push(self, s, a, r, ns, d):
        self.s[self.pos]  = (s  * 255).clip(0, 255).astype(np.uint8)
        self.ns[self.pos] = (ns * 255).clip(0, 255).astype(np.uint8)
        self.a[self.pos] = a; self.r[self.pos] = r; self.d[self.pos] = float(d)
        self.pos = (self.pos + 1) % self.cap
        self.size = min(self.size + 1, self.cap)

    def sample(self, n):
        i = np.random.randint(0, self.size, n)
        return (self.s[i] / 255., self.a[i], self.r[i], self.ns[i] / 255., self.d[i])

    def __len__(self): return self.size


class Agent:
    def __init__(self):
        self.policy = DQN().to(device)
        self.target = DQN().to(device)
        self.target.load_state_dict(self.policy.state_dict())
        self.target.eval()
        self.opt    = optim.Adam(self.policy.parameters(), lr=LR)
        self.buf    = ReplayBuffer(BUFFER_SIZE)
        self.eps    = EPS_START
        self.steps  = 0

    def act_batch(self, states):
        with torch.no_grad():
            q = self.policy(torch.FloatTensor(np.array(states)).to(device)).cpu().numpy()
        greedy = q.argmax(axis=1)
        mask   = np.random.random(NUM_ENVS) < self.eps
        return np.where(mask, np.random.randint(0, 2, NUM_ENVS), greedy)

    def train_step(self):
        if len(self.buf) < LEARN_START:
            return None
        s, a, r, ns, d = self.buf.sample(BATCH_SIZE)
        s  = torch.FloatTensor(s).to(device)
        ns = torch.FloatTensor(ns).to(device)
        a  = torch.LongTensor(a).to(device)
        r  = torch.FloatTensor(r).to(device)
        d  = torch.FloatTensor(d).to(device)
        with torch.no_grad():
            na = self.policy(ns).argmax(1)
            tq = r + GAMMA * self.target(ns).gather(1, na.unsqueeze(1)).squeeze(1) * (1 - d)
        loss = nn.HuberLoss()(self.policy(s).gather(1, a.unsqueeze(1)).squeeze(1), tq)
        self.opt.zero_grad(); loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), 10.0)
        self.opt.step()
        return loss.item()

    def update_eps(self):
        self.eps = max(EPS_END, EPS_START - (EPS_START - EPS_END) * self.steps / EPS_DECAY)

    def sync_target(self):
        self.target.load_state_dict(self.policy.state_dict())

    def save(self, path=MODEL_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save(self.policy.state_dict(), path)
        print(f"  Saved → {path}")

    def load(self, path=MODEL_PATH):
        self.policy.load_state_dict(torch.load(path, map_location=device))
        self.target.load_state_dict(self.policy.state_dict())
        print(f"  Loaded ← {path}")


def train(log_cb=None):
    agent  = Agent()
    if RESUME_FROM:
        agent.load(RESUME_FROM)

    envs   = [GameInstance(bird_color="blue") for _ in range(NUM_ENVS)]
    states = [e.reset_rl() for e in envs]
    scores = [0.0] * NUM_ENVS
    hist   = []; losses = []; t0 = time.time()

    print(f"Device: {device}")
    print(f"START | {NUM_ENVS} GameInstance envs | target {MAX_STEPS:,} steps")
    print(f"Checkpoint every {CHECKPOINT_EVERY:,} | Time limit {TIME_LIMIT_SEC}s")
    print("-" * 65)

    for step in range(1, MAX_STEPS + 1):
        agent.steps = step
        agent.update_eps()

        actions = agent.act_batch(states)

        for i, env in enumerate(envs):
            ns, reward, done = env.step_rl(int(actions[i]))
            agent.buf.push(states[i], actions[i], reward, ns, done)
            scores[i] += reward
            if done:
                hist.append(scores[i])
                scores[i] = 0.0
                states[i] = env.reset_rl()
            else:
                states[i] = ns

        loss = agent.train_step()
        if loss:
            losses.append(loss)

        if step % TARGET_UPDATE    == 0: agent.sync_target()
        if step % CHECKPOINT_EVERY == 0: agent.save()

        if time.time() - t0 >= TIME_LIMIT_SEC:
            agent.save()
            print(f"\nTime limit at step {step:,}. Saved.")
            break

        if step % LOG_EVERY == 0 and hist:
            rec  = hist[-300:]
            avg  = np.mean(rec)
            best = int(max(rec))
            fps  = step / (time.time() - t0)
            avgl = np.mean(losses[-500:]) if losses else 0
            line = (f"Step {step:>10,} | Avg {avg:6.2f} | Best {best:4d} | "
                    f"Eps {agent.eps:.3f} | Loss {avgl:.5f} | FPS {fps:.0f}")
            print(line)
            if log_cb:
                log_cb(step, hist, losses)

    agent.save()
    elapsed = time.time() - t0
    print(f"\nDone — {step:,} steps in {elapsed/60:.1f} min  ({step/elapsed:.0f} steps/sec)")
    return agent, hist


if __name__ == "__main__":
    train()